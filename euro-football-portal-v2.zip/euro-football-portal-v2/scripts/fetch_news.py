import json,re
from datetime import datetime,timezone
from urllib.request import Request,urlopen
import xml.etree.ElementTree as ET
from pathlib import Path
FEEDS=[('BBC Sport','https://feeds.bbci.co.uk/sport/football/rss.xml'),('The Guardian Football','https://www.theguardian.com/football/rss'),('Sky Sports Football','https://www.skysports.com/rss/12040'),('ESPN FC','https://www.espn.com/espn/rss/soccer/news')]
SAFE={'bbc.co.uk','theguardian.com','skysports.com','espn.com'}
KEY={'ucl':['champions league'],'epl':['premier league','manchester united','manchester city','liverpool','arsenal','chelsea','tottenham','newcastle'],'laliga':['la liga','real madrid','barcelona','atletico madrid'],'seriea':['serie a','inter','milan','juventus','roma','atalanta'],'bundesliga':['bundesliga','bayern','borussia dortmund'],'transfer':['transfer','signed','deal','loan','move','fee'],'preview':['preview','pre-match'],'review':['review','reaction','analysis'],'legend':['legend','former','icon']}
PRIO=['real madrid','mourinho','barcelona','manchester city','manchester united','liverpool','arsenal','chelsea','tottenham','newcastle','inter','milan','juventus','roma','atalanta','bayern']
def clean(x): return re.sub(r'\s+',' ',re.sub('<[^>]+>',' ',x or '')).strip()
def classify(t):
    t=t.lower()
    if 'champions league' in t:return 'ucl','CL','ucl'
    for c,ws in KEY.items():
        if any(w in t for w in ws): return c,{'epl':'プレミア','laliga':'ラ・リーガ','seriea':'セリエA','bundesliga':'ブンデス','transfer':'移籍','preview':'プレビュー','review':'レビュー','legend':'レジェンド・OB'}.get(c,'その他'),c
    return 'other','その他','other'
out=[]
for source,url in FEEDS:
    try:
        root=ET.fromstring(urlopen(Request(url,headers={'User-Agent':'EURO-Football-Portal/1.0'}),timeout=15).read())
        for x in root.findall('.//item')[:30]:
            title=clean(x.findtext('title'));link=clean(x.findtext('link'));desc=clean(x.findtext('description'));pub=clean(x.findtext('pubDate'))
            if not title or not link:continue
            domain=re.sub(r'^www\.','',link.split('/')[2].lower())
            if not any(domain==d or domain.endswith('.'+d) for d in SAFE):continue
            cat,label,typ=classify(title+' '+desc);low=(title+' '+desc).lower();featured=any(k in low for k in PRIO)
            out.append({'title':title,'summary':desc[:360],'source':source,'url':link,'published':pub,'category':cat,'type':typ,'label':label,'featured':featured})
    except Exception as e: print(source,e)
seen=set();ded=[]
for n in out:
    k=re.sub(r'\W+','',n['title'].lower())
    if k not in seen:seen.add(k);ded.append(n)
ded.sort(key=lambda n:(100 if n['featured'] else 0,30 if n['type']=='transfer' else 0,{'ucl':90,'epl':80,'laliga':70,'seriea':60,'bundesliga':50}.get(n['category'],20),n['published']),reverse=True)
Path('data/news.json').write_text(json.dumps({'updated_at':datetime.now(timezone.utc).isoformat(),'items':ded[:200]},ensure_ascii=False,indent=2),encoding='utf-8')
